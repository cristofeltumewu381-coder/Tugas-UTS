<?php $__env->startSection("title", "Kategori"); ?>
<?php $__env->startSection("content"); ?>
<div class="d-flex justify-content-between mb-3">
    <h3>Daftar Kategori</h3>
    <a href="<?php echo e(route("categories.create")); ?>" class="btn btn-primary">+ Tambah Kategori</a>
</div>
<div class="table-responsive">
<table class="table table-bordered bg-white">
    <thead class="table-dark"><tr><th>#</th><th>Nama</th><th>Deskripsi</th><th>Jml Buku</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($c->name); ?></td>
            <td><?php echo e($c->description ?? "-"); ?></td>
            <td><?php echo e($c->books_count); ?></td>
            <td class="text-nowrap">
                <a href="<?php echo e(route("categories.edit", $c)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route("categories.destroy", $c)); ?>" method="POST" class="d-inline"
                      onsubmit="return confirm('Hapus kategori ini?')">
                    <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                    <button class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" class="text-center">Belum ada kategori.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/categories/index.blade.php ENDPATH**/ ?>