<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mini-Perpus - <?php echo $__env->yieldContent("title"); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route("books.index")); ?>">Mini-Perpus</a>
        <div class="navbar-nav">
            <a class="nav-link" href="<?php echo e(route("books.index")); ?>">Buku</a>
            <a class="nav-link" href="<?php echo e(route("categories.index")); ?>">Kategori</a>
        </div>
    </div>
</nav>
<div class="container">
    <?php if(session("success")): ?> <div class="alert alert-success"><?php echo e(session("success")); ?></div> <?php endif; ?>
    <?php if(session("error")): ?> <div class="alert alert-danger"><?php echo e(session("error")); ?></div> <?php endif; ?>
    <?php echo $__env->yieldContent("content"); ?>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\mini-perpus\resources\views/layouts/app.blade.php ENDPATH**/ ?>