<?php $__env->startSection("title", "Tambah Buku"); ?>
<?php $__env->startSection("content"); ?>
<h3>Tambah Buku</h3>
<form action="<?php echo e(route("books.store")); ?>" method="POST">
    <?php echo $__env->make("books._form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/books/create.blade.php ENDPATH**/ ?>