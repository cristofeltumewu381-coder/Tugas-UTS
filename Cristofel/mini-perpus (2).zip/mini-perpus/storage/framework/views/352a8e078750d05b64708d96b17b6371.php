<?php $__env->startSection("title", "Edit Buku"); ?>
<?php $__env->startSection("content"); ?>
<h3>Edit Buku</h3>
<form action="<?php echo e(route("books.update", $book)); ?>" method="POST">
    <?php echo method_field("PUT"); ?>
    <?php echo $__env->make("books._form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/books/edit.blade.php ENDPATH**/ ?>