<?php $__env->startSection("title", "Edit Kategori"); ?>
<?php $__env->startSection("content"); ?>
<h3>Edit Kategori</h3>
<form action="<?php echo e(route("categories.update", $category)); ?>" method="POST">
    <?php echo method_field("PUT"); ?>
    <?php echo $__env->make("categories._form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/categories/edit.blade.php ENDPATH**/ ?>