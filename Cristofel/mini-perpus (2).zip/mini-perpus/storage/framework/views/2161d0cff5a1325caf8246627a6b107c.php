<?php $__env->startSection("title", "Tambah Kategori"); ?>
<?php $__env->startSection("content"); ?>
<h3>Tambah Kategori</h3>
<form action="<?php echo e(route("categories.store")); ?>" method="POST">
    <?php echo $__env->make("categories._form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/categories/create.blade.php ENDPATH**/ ?>