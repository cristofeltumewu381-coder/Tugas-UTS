<?php $__env->startSection("title", "Buku"); ?>
<?php $__env->startSection("content"); ?>
<div class="d-flex justify-content-between mb-3">
    <h3>Daftar Buku</h3>
    <a href="<?php echo e(route("books.create")); ?>" class="btn btn-primary">+ Tambah Buku</a>
</div>
<div class="table-responsive">
<table class="table table-bordered bg-white">
    <thead class="table-dark"><tr><th>#</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Tahun</th><th>Stok</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($b->title); ?></td>
            <td><?php echo e($b->author); ?></td>
            <td><?php echo e($b->category->name); ?></td>
            <td><?php echo e($b->published_year); ?></td>
            <td><?php echo e($b->stock); ?></td>
            <td class="text-nowrap">
                <a href="<?php echo e(route("books.edit", $b)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route("books.destroy", $b)); ?>" method="POST" class="d-inline"
                      onsubmit="return confirm('Hapus buku ini?')">
                    <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                    <button class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center">Belum ada buku.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-perpus\resources\views/books/index.blade.php ENDPATH**/ ?>