@csrf
<div class="mb-3">
    <label class="form-label">Nama Kategori</label>
    <input type="text" name="name" class="form-control @error("name") is-invalid @enderror"
           value="{{ old("name", $category->name ?? "") }}">
    @error("name") <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>
<div class="mb-3">
    <label class="form-label">Deskripsi</label>
    <textarea name="description" rows="3" class="form-control @error("description") is-invalid @enderror">{{ old("description", $category->description ?? "") }}</textarea>
    @error("description") <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>
<button class="btn btn-primary">Simpan</button>
<a href="{{ route("categories.index") }}" class="btn btn-secondary">Batal</a>
