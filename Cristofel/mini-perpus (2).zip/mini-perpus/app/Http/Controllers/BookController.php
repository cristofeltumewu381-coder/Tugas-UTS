<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class BookController extends Controller
{
    private function rules(): array
    {
        return [
            "category_id" => "required|exists:categories,id",
            "title" => "required|max:255",
            "author" => "required|max:100",
            "published_year" => "required|numeric",
            "stock" => "required|integer|min:0",
        ];
    }

    public function index()
    {
        $books = Book::with("category")->latest()->get();
        return view("books.index", compact("books"));
    }

    public function create()
    {
        $categories = Category::orderBy("name")->get();
        return view("books.create", compact("categories"));
    }

    public function store(Request $request)
    {
        Book::create($request->validate($this->rules()));
        return redirect()->route("books.index")->with("success", "Buku berhasil ditambahkan.");
    }

    public function edit(Book $book)
    {
        $categories = Category::orderBy("name")->get();
        return view("books.edit", compact("book", "categories"));
    }

    public function update(Request $request, Book $book)
    {
        $book->update($request->validate($this->rules()));
        return redirect()->route("books.index")->with("success", "Buku berhasil diperbarui.");
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->route("books.index")->with("success", "Buku berhasil dihapus.");
    }
}
